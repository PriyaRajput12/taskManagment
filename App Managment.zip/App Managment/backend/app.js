let express = require("express")
let bodyParser = require("body-parser")
let path = require("path")
let cors = require("cors")

let app = express()
port = 4000
app.use(bodyParser.json())
app.use(cors())
let user = [
     {
    name:"priya",
    pass :"565",
     }
]

app.get("/",(req,res)=>{
    res.json(user)

});

app.get("/home",(req,res)=>{
    res.json(manageTask)
})

app.listen(port,()=>{
    console.log(`server is running on ${port}`)
})