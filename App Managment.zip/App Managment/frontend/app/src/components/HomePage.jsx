import React, { useState } from 'react'

const HomePage = () => {
  let [state, setState] = useState({Title:'',Description:''})
  let [newstate, setNewState] = useState([])
  let handlesubmit = (e) => {
    setNewState((preval) => {
      return [...preval, state]
    })
    setState("")
    e.preventDefault()
  }
  return (
    <div>
      <h1 className='text-danger'>my Home Page</h1>
      <form action="" onSubmit={handlesubmit}>
        <input type="text" value={Title} onChange={(e) => setState(e.target.value)} placeholder='enter title' />
        <input type="text" value={Description} onChange={(e) => setState(e.target.value)} placeholder='enter description' />
        <button type='submit' >COMPLETED</button>
      </form>
      {/* <table className='table table-bordered table stripped w-50'>
        <thead>
          <tr>
            <td>ID</td>
            <td>TITTLE</td>
            <td>DESCRIPTION</td>

          </tr>
        </thead>
        <ol>
        <tbody>
          {newstate.map(({Title,Description}) => {
            return (
              <>
                {Title}
                {Description}
              </>
            )
          })}
        </tbody>
        </ol>
      </table> */}
    </div>
  )
}


export default HomePage
