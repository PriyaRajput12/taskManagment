import React from 'react'

const home = () => {
  return (
    <div>
      <h1>Home</h1>
    </div>
  )
}

export default home
