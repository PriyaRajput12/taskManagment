import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'



const Login = () => {
  const [state, setState] = useState([])
  const [name, setName] = useState([])
  const [pass, setPass] = useState({})
  let history = useNavigate();

  useEffect(() => {
    axios.get("http://localhost:4000/")
      .then((res) => setState(res.data))
  }, [])


  const hadlelogin = () => {
    state.map((temp) => {
      const { userName, userPassword } = temp
      if (name === userName && pass === userPassword) {
        console.log('login sucessfull')
        history('/home')
      }
      else {
        console.log('invalid details')
      }
      return true;
    }
    )
  }
  return (
    <div>
      {
        state.map((temp, index) => {
          return (

            <div className='m-auto mt-5  d-flex justify-content-center align-items-center'>
              <form onSubmit={hadlelogin} action='./home' className='form-control w-25 d-grid justify-content-center align-items-center'>
                <h1>Login Form</h1>
                <label htmlFor="exampleInputEmail1" className="form-label m-2">Name</label>
                <input type="text" name='name' value={name} onChange={(e) => setName(e.target.value)} />

                <label htmlFor="" className="form-label m-2">Password</label>
                <input type="password" name='pass' value={pass} onChange={(e) => setPass(e.target.value)} />


                <button type='submit' className="btn btn-primary m-2">Login</button>
              </form>
            </div>
          )
        })
      }
    </div>
  )
}


export default Login